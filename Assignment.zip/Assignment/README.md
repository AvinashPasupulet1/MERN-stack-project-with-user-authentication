# MERN Assignment

This is a full-stack MERN project with authentication, agents management, and file upload.

## Project Structure
- `server/` → Node.js + Express + MongoDB backend
- `client/` → React (Vite) frontend

---

## Setup Instructions

### 1. Clone and Install Dependencies
```bash
git clone <your-repo-url>
cd mern-assignment-fixed

# Install server dependencies
cd server
npm install

# Install client dependencies
cd ../client
npm install
```

### 2. Environment Variables
Create `.env` files from the provided `.env.example` files.

#### Server (`server/.env`)
```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/mern_assignment
JWT_SECRET=your_secret_key
```

#### Client (`client/.env`)
```env
VITE_API_URL=http://localhost:5000
```

### 3. Run the Project

#### Start Backend
```bash
cd server
npm run dev   # if nodemon configured
# or
npm start
```

#### Start Frontend
```bash
cd client
npm run dev
```

- Backend → http://localhost:5000  
- Frontend → http://localhost:5173

---

## Features
- User authentication with JWT
- Agents management (CRUD)
- File upload endpoint
- Protected routes in React

---

## Tech Stack
- **Backend:** Node.js, Express, MongoDB, Mongoose
- **Frontend:** React (Vite), Fetch API
- **Auth:** JWT
